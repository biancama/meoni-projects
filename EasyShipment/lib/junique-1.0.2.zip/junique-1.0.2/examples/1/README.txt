A simple textpad, blocking multiple instances.

Try to launch this command more than once:

java -Djava.ext.dirs=../../ -jar textpad.jar

(otherwise launch run.bat)

