/**
 * Contains classes and interfaces used by the {@code JXDatePicker} and
 * {@code JXMonthView} components.
 */
package org.jdesktop.swingx.calendar;

